import importlib.metadata

__version__ = importlib.metadata.version("cse599o-systems")