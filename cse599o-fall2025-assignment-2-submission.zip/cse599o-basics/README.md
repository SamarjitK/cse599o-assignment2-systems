# CSE599o Fall 2025 Assignment 1: Basics

This folder contains the files from assignment 1 that you'll need for assignment
2.

Note that this is not a complete implementation of assignment 1, just the bits
that are carried forward for assignment 2.
